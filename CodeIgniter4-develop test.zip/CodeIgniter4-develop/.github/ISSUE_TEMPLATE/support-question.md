---
name: Support question
about: How to ask a support question
title: ''
labels: ''
assignees: ''

---

Please ask support questions on our [forum](https://forum.codeigniter.com/forum-30.html).
We use github issues to track bugs and planned work.
